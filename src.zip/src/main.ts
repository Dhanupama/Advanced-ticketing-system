import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, Routes } from '@angular/router';
import { FormPageComponent } from './app/form-page/form-page.component';

const routes: Routes = [
  { path: '', component: FormPageComponent }, // Default route to FormPageComponent
];

bootstrapApplication(FormPageComponent, {
  providers: [provideRouter(routes)],
}).catch(err => console.error(err));
