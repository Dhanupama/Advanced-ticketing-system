import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common'; // For common directives (like ngIf, ngFor)
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-form-page',
  templateUrl: './form-page.component.html',
  styleUrls: ['./form-page.component.css'],
  standalone: true, // Mark the component as standalone
  imports: [CommonModule, FormsModule] // Import necessary modules
})
export class FormPageComponent {
  formData = {
    input1: '',
    input2: '',
    input3: '',
    input4: '',
    input5: '',
    input6: ''
  };

  constructor(private http: HttpClient) {}

  onSubmit() {
    const apiUrl = 'https://your-api-endpoint.com/submit';
    this.http.post(apiUrl, this.formData).subscribe(
      response => {
        console.log('Form submitted successfully', response);
      },
      error => {
        console.error('Error submitting form', error);
      }
    );
  }

  onClear() {
    this.formData = {
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      input5: '',
      input6: ''
    };
  }

  onSave() {
    const apiUrl = 'https://your-api-endpoint.com/save';
    this.http.post(apiUrl, this.formData).subscribe(
      response => {
        console.log('Form data saved', response);
      },
      error => {
        console.error('Error saving form data', error);
      }
    );
  }

  onReset() {
    this.formData = {
      input1: '',
      input2: '',
      input3: '',
      input4: '',
      input5: '',
      input6: ''
    };
  }
}
